<!DOCTYPE html>
<html>
<head>
    <title>Your OTP Code</title>
</head>
<body>
    <p>Your OTP code is: {{ $otp }}</p>
</body>
</html>
