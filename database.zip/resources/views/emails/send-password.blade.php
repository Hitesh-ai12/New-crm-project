<p>Your account password is: {{ $password }}</p>
