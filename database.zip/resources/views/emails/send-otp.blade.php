<p>Your OTP is: {{ $otp }}</p>
