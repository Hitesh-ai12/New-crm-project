<template>
    <div>
      <h1>About Page</h1>
      <p>Welcome to the About page!</p>
    </div>
  </template>
  
  <script lang="ts">
  export default {
    name: 'About',
  }
  </script>
  
  <style scoped>
  /* Add your styles here */
  </style>
  